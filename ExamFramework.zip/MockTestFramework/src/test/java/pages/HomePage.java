package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends BasePage {

    @FindBy(id = "cartur")
    WebElement cartTag;

    @FindBy(xpath = "//button[text()='Place Order']")
    WebElement placeOrder;

    @FindBy(id = "login2")
    WebElement loginTag;

    @FindBy(id = "loginusername")
    WebElement usernameTag;

    @FindBy(id = "loginpassword")
    WebElement passwordTag;

    @FindBy(xpath = "//button[text()='Log in']")
    WebElement loginButton;

    @FindBy(id = "logout2")
    WebElement logoutTag;

    @FindBy(xpath = "//a[text()='Samsung galaxy s6']")
    WebElement firstMobileTextBefore;

    @FindBy(xpath = "//h2[@class='name']")
    WebElement firstMobileTextAfter;

    @FindBy(xpath = "//li[1]/a[@class='nav-link']")
    WebElement homeTag;

    @FindBy(id = "cat")
    WebElement categoriesTag;

    @FindBy(xpath = "//button[text()='Purchase']")
    WebElement purchaseButton;

    @FindBy(xpath = "//div[@id='orderModal']/div/div/div[3]/button[1]")
    WebElement closeButton;

    String beforeTest;
    String afterTest;


    public void openWebsite() {
        driver.get("https://www.demoblaze.com/");
    }


    public boolean isHomePageIsDisplayed() {
        return cartTag.isDisplayed();
    }

    public void clickOnCart() {
        cartTag.click();
    }

    public boolean validateCartPage() {
        return placeOrder.isDisplayed();
    }

    public void clickOnLogin() {
        loginTag.click();

    }

    public void fillTheUsernameAndPassword(String username, String password) {
        usernameTag.sendKeys(username);
        passwordTag.sendKeys(password);
        loginButton.click();
    }

    public boolean isLogoutDisplay() {
        return loginButton.isDisplayed();
    }

    public void clickOnFirstPhone() {
        beforeTest = firstMobileTextBefore.getText();
        firstMobileTextBefore.click();
    }

    public boolean validateTheMobilePhoneBeforeAndAfter() {
        afterTest = firstMobileTextAfter.getText();
        return beforeTest.equals(afterTest);
    }

    public void clickOnHomeTag() {
        homeTag.click();
    }

    public boolean isAgainHomePageIsDisplayed() {
        return categoriesTag.isDisplayed();
    }

    public void clickOnPlaceOrder() {
        placeOrder.click();
    }

    public boolean isPurchaseButtonAvailable() {
        return purchaseButton.isDisplayed();
    }

    public void clickOnCloseButton() {
        closeButton.click();
    }
}
