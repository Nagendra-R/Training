package pages;

import io.qameta.allure.testng.AllureTestNg;

public class AllureListener extends AllureTestNg {

}
