package test;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;
import utils.ConfigReader;


public class MainTest extends BaseTest {

    @Test
    public void validateCartPage() throws InterruptedException {
        HomePage homePage = new HomePage();
        homePage.openWebsite();
        Assert.assertTrue(homePage.isHomePageIsDisplayed(), "HomePage is not displayed");
        homePage.clickOnCart();
        Assert.assertTrue(homePage.validateCartPage(), "Cart Tag is Not Working ");
        homePage.clickOnPlaceOrder();
        Thread.sleep(2000);
        Assert.assertTrue(homePage.isPurchaseButtonAvailable(),"purchase button is not displayed");
        homePage.clickOnCloseButton();
        Assert.assertTrue(homePage.validateCartPage(),"Its not closing");
    }

    @Test
    public void validateUserCanLogin() {
        HomePage homePage = new HomePage();
        homePage.openWebsite();
        homePage.clickOnLogin();
        homePage.fillTheUsernameAndPassword(ConfigReader.configValue("username"), ConfigReader.configValue("password"));
        Assert.assertTrue(homePage.isLogoutDisplay(), "login is failure");
    }


}
