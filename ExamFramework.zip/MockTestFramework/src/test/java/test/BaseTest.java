package test;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import utils.ConfigReader;
import utils.DriverManager;

import java.io.FileNotFoundException;

public class BaseTest {

    @BeforeMethod
    public void setUp() throws FileNotFoundException {
        ConfigReader.initProperties();
        DriverManager.createDriver();
    }

    @AfterMethod
    public void clean() {
        DriverManager.getDriver().close();
    }

}
