package steps;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import utils.DriverManager;

import java.net.MalformedURLException;

public class Hooks {

    @Before
    public void setUp() throws MalformedURLException {
        DriverManager.createDriver();
        System.out.println("Before Scenario");
    }

    @After
    public void clean() {
        System.out.println("After Scenario");
        DriverManager.getDriver().close();
    }


}
