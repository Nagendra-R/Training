package steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.testng.Assert;
import pages.HomePage;

public class StepDef {

    HomePage homePage = new HomePage();


    @Given("user open the website")
    public void user_open_the_website() {
        homePage.openWebsite();
    }

    @Then("validate user on homepage")
    public void validate_user_on_homepage() {
        Assert.assertTrue(homePage.isHomePageIsDisplayed(), "homepage is not displayed");
    }

    @When("click on first phone")
    public void click_on_first_phone() {
        homePage.clickOnFirstPhone();
    }

    @Then("validate the same mobile phone is displayed")
    public void validate_the_same_mobile_phone_is_displayed() {
        Assert.assertTrue(homePage.validateTheMobilePhoneBeforeAndAfter(), "Both mobile text are different ");
    }


    @When("user click on cart link")
    public void user_click_on_cart_link() {
        homePage.clickOnCart();
    }

    @Then("validate the cart page")
    public void validate_the_cart_page() {
        homePage.validateCartPage();
    }

    @When("click on home link")
    public void click_on_home_link() {
        homePage.clickOnHomeTag();
    }

    @Then("validate user on again homepage")
    public void validate_user_on_again_homepage() {
        Assert.assertTrue(homePage.isAgainHomePageIsDisplayed(), "Not a HomePage");
    }
}
